import time

# Quick Sort function
def quick_sort(arr):
    if len(arr) <= 1:
        return arr

    pivot = arr[-1]

    left = []
    middle = []
    right = []

    for x in arr:
        if x < pivot:
            left.append(x)
        elif x == pivot:
            middle.append(x)
        else:
            right.append(x)

    return quick_sort(left) + middle + quick_sort(right)


# -------------------------------
# Main Program
# -------------------------------

n = int(input("Enter number of elements: "))

arr = list(map(int, input("Enter elements separated by spaces: ").split()))

if len(arr) != n:
    print("Error: Please enter exactly", n, "elements.")
else:
    print("\nOriginal array:", arr)

    # Start timer
    start_time = time.perf_counter()

    # Perform Quick Sort
    sorted_arr = quick_sort(arr)

    # Stop timer
    end_time = time.perf_counter()

    # Calculate execution time
    execution_time = end_time - start_time

    print("Sorted array:", sorted_arr)
    print("Execution time:", execution_time, "seconds")

    print("\nTime Complexity:")
    print("Best Case    : O(n log n)")
    print("Average Case : O(n log n)")
    print("Worst Case   : O(n²)")

    print("Space Complexity: O(n)")