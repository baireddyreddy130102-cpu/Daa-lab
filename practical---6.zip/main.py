import time


def matrix_chain_order(p, n):
    # dp[i][j] stores the minimum number of scalar
    # multiplications needed to multiply matrices
    # from matrix i to matrix j.
    dp = [[0 for _ in range(n)] for _ in range(n)]

    # Chain length starts from 2
    for length in range(2, n):
        for i in range(1, n - length + 1):
            j = i + length - 1

            dp[i][j] = float('inf')

            # Try every possible split
            for k in range(i, j):
                cost = (
                    dp[i][k]
                    + dp[k + 1][j]
                    + p[i - 1] * p[k] * p[j]
                )

                if cost < dp[i][j]:
                    dp[i][j] = cost

    return dp[1][n - 1]


# --------------------------------
# User Input
# --------------------------------

num_matrices = int(input("Enter number of matrices: "))

print("\nEnter dimensions of the matrices.")

print("For example, for matrices:")
print("A1 = 10 x 20")
print("A2 = 20 x 30")
print("A3 = 30 x 40")
print("Enter: 10 20 30 40\n")

dimensions = list(
    map(
        int,
        input("Enter dimensions separated by spaces: ").split()
    )
)

# Check whether correct number of dimensions is entered
if len(dimensions) != num_matrices + 1:
    print(
        "Error: You must enter",
        num_matrices + 1,
        "dimensions."
    )
else:

    # --------------------------------
    # Measure Execution Time
    # --------------------------------

    start_time = time.perf_counter()

    min_operations = matrix_chain_order(
        dimensions,
        num_matrices + 1
    )

    end_time = time.perf_counter()

    execution_time = end_time - start_time

    # --------------------------------
    # Output
    # --------------------------------

    print("\nMinimum number of scalar multiplications:",
          min_operations)

    print("Execution time:",
          execution_time,
          "seconds")