import time

def knapsack(weights, values, capacity, n):
    # DP table
    dp = [[0 for _ in range(capacity + 1)] for _ in range(n + 1)]

    # Build the DP table
    for i in range(1, n + 1):
        for w in range(1, capacity + 1):

            if weights[i - 1] <= w:
                # Maximum of:
                # 1. Including the current item
                # 2. Excluding the current item
                dp[i][w] = max(
                    values[i - 1] + dp[i - 1][w - weights[i - 1]],
                    dp[i - 1][w]
                )
            else:
                # Cannot include the current item
                dp[i][w] = dp[i - 1][w]

    return dp[n][capacity]


# -------------------------------
# User Input
# -------------------------------

n = int(input("Enter number of items: "))

weights = []
values = []

for i in range(n):
    weight = int(input(f"Enter weight of item {i + 1}: "))
    value = int(input(f"Enter value of item {i + 1}: "))

    weights.append(weight)
    values.append(value)

capacity = int(input("Enter knapsack capacity: "))


# -------------------------------
# Measure Execution Time
# -------------------------------

start_time = time.perf_counter()

max_value = knapsack(weights, values, capacity, n)

end_time = time.perf_counter()

execution_time = end_time - start_time


# -------------------------------
# Output
# -------------------------------

print("\nMaximum value:", max_value)
print("Execution time:", execution_time, "seconds")